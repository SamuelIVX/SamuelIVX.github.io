// Isolated visual study; reuse the installed portfolio toolchain without changing it.
import { defineConfig } from 'vite';
import react from '@vitejs/plugin-react';
export default defineConfig({ plugins: [react()], cacheDir: '.vite' });
