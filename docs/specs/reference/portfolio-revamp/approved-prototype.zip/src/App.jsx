// Three isolated layout studies of the approved creative direction; state stays in memory.
import { useEffect, useId, useRef, useState } from 'react';
import { motion } from 'motion/react';
import { flushSync } from 'react-dom';
import useReducedMotion from './useReducedMotion.js';
import { projects, experiences, honors } from './content.js';
import DotGrid from './components/DotGrid.jsx';

const layouts = ['A', 'B', 'C'];
const layoutNames = { A: 'Open studio', B: 'Studio + work index', C: 'Type study' };
const sections = [['about', 'About'], ['projects', 'Projects'], ['work', 'Experience'], ['honors', 'Honors'], ['contact', 'Contact']];

/** Decorative line icons; interactive elements provide their own accessible labels. */
function Icon({ name, className = '' }) {
  const paths = {
    arrow: <path d="M5 15 15 5M5 5h10v10" />,
    down: <path d="M10 3v14m-5-5 5 5 5-5" />,
    left: <path d="m12 4-6 6 6 6" />,
    right: <path d="m8 4 6 6-6 6" />,
    code: <path d="m6 5-5 5 5 5m8-10 5 5-5 5m-3-12-2 14" />,
    screen: <><rect x="2" y="3" width="16" height="11" rx="2" /><path d="M7 18h6m-3-4v4" /></>,
    linkedin: <><rect x="2" y="2" width="16" height="16" rx="3" /><path d="M6 9v6m0-10v.2M10 15V9m0 3c0-4 4-4 4-1v4" /></>,
    github: <path d="M9 19c-4.3 1.3-4.3-2.2-6-2.7M15 22v-3.9c0-1.1-.4-1.9-1-2.4 3.3-.4 6.8-1.6 6.8-7.3 0-1.6-.6-2.9-1.5-3.9.2-.4.7-1.9-.1-3.5 0 0-1.2-.4-4 1.5a13.8 13.8 0 0 0-7.2 0C5.2.6 4 .9 4 .9c-.8 1.6-.3 3.1-.1 3.5A5.6 5.6 0 0 0 2.4 8c0 5.7 3.5 6.9 6.8 7.3-.5.5-.9 1.2-1 2.4V22" />,
    sun: <><circle cx="10" cy="10" r="3.5" /><path d="M10 1v2m0 14v2M1 10h2m14 0h2M3.6 3.6 5 5m10 10 1.4 1.4M3.6 16.4 5 15M15 5l1.4-1.4" /></>,
    moon: <path d="M17 12.4A7.4 7.4 0 0 1 7.6 3a7.4 7.4 0 1 0 9.4 9.4Z" />,
    plus: <path d="M3 10h14m-7-7v14" />
  };
  return <svg className={`icon ${className}`} viewBox={name === 'github' ? '0 0 24 24' : '0 0 20 20'} fill="none" stroke="currentColor" strokeWidth="1.4" strokeLinecap="round" strokeLinejoin="round" aria-hidden="true">{paths[name]}</svg>;
}

/** A single native scroll-snap row: manual controls, touch scrolling and no autoplay. */
function ProjectCarousel() {
  const rail = useRef(null);
  const [position, setPosition] = useState({ start: 0, visible: 3 });
  const maxStart = Math.max(0, projects.length - position.visible);
  useEffect(() => {
    const element = rail.current;
    let frame = 0;
    const update = () => {
      frame = 0;
      const cards = element.querySelectorAll('.project-slide');
      const gap = parseFloat(getComputedStyle(element).columnGap);
      const stride = cards[0].getBoundingClientRect().width + gap;
      const visible = Math.min(projects.length, Math.max(1, Math.round((element.clientWidth + gap) / stride)));
      const start = Math.min(projects.length - visible, Math.max(0, Math.round(element.scrollLeft / stride)));
      setPosition(previous => previous.start === start && previous.visible === visible ? previous : { start, visible });
    };
    const queue = () => { if (!frame) frame = requestAnimationFrame(update); };
    const observer = new ResizeObserver(queue);
    observer.observe(element);
    element.addEventListener('scroll', queue, { passive: true });
    update();
    return () => { cancelAnimationFrame(frame); observer.disconnect(); element.removeEventListener('scroll', queue); };
  }, []);

  function goTo(index) {
    const element = rail.current;
    const cards = element.querySelectorAll('.project-slide');
    const target = Math.min(maxStart, Math.max(0, index));
    const left = cards[target].getBoundingClientRect().left - cards[0].getBoundingClientRect().left;
    // Read the current preference at the action, including a just-changed media setting.
    element.scrollTo({ left, behavior: matchMedia('(prefers-reduced-motion: reduce)').matches ? 'instant' : 'smooth' });
  }

  function onKeyDown(event) {
    if (event.target.closest('a') || event.ctrlKey || event.metaKey || event.altKey) return;
    let target;
    if (event.key === 'ArrowLeft') target = position.start - 1;
    else if (event.key === 'ArrowRight') target = position.start + 1;
    else if (event.key === 'Home') target = 0;
    else if (event.key === 'End') target = maxStart;
    else return;
    event.preventDefault();
    event.stopPropagation();
    goTo(target);
  }

  return <div className="project-carousel" data-project-carousel role="region" aria-roledescription="carousel" aria-label="Projects" onKeyDown={onKeyDown} data-reveal>
    <div className="project-toolbar"><div className="project-controls"><button type="button" aria-label="Previous projects" disabled={position.start === 0} onClick={() => goTo(position.start - 1)}><Icon name="left" /></button><button type="button" aria-label="Next projects" disabled={position.start >= maxStart} onClick={() => goTo(position.start + 1)}><Icon name="right" /></button></div></div>
    <div className="project-track" ref={rail} tabIndex={0} aria-label="Project cards">
      {projects.map((project, index) => <article className="project-slide" key={project.repo} aria-label={`${project.name}, project ${index + 1} of ${projects.length}`}><div className="project-card">
        <div className="project-visual">{project.image ? <img src={`/assets/${project.image}`} alt={`${project.name} preview from the existing portfolio`} width="1400" height="840" loading="lazy" /> : <Schedule />}</div>
        <div className="project-copy"><p className="eyebrow">{project.kind}</p><h3>{project.name}</h3><p>{project.description}</p><ul className="tags" aria-label="Technologies">{project.tech.map(tech => <li key={tech}>{tech}</li>)}</ul><div className="project-links"><External href={`https://github.com/SamuelIVX/${project.repo}`} icon="code">Source code</External>{project.demo ? <External href={project.demo} icon="screen">Live demo</External> : null}</div></div>
      </div></article>)}
    </div>
    <div className="project-positions" aria-label="Project position">{Array.from({ length: maxStart + 1 }, (_, index) => <button type="button" key={index} aria-label={`Show projects starting with ${projects[index].name}`} aria-current={position.start === index ? 'true' : undefined} onClick={() => goTo(index)}><span aria-hidden="true" /></button>)}</div>
  </div>;
}

/** External links stay ordinary anchors, including the resume and project actions. */
function External({ href, children, icon, className = '' }) {
  return <a className={`text-link ${className}`} href={href} target="_blank" rel="noopener noreferrer">{icon ? <Icon name={icon} /> : null}{children}<Icon name="arrow" /></a>;
}

/** Readable, static schedule illustration for Interleave, not a fabricated app screenshot. */
function Schedule() {
  return <div className="schedule" role="img" aria-label="Illustrative interleaving of two threads, exploring their execution schedules">
    <div className="schedule-heading"><span>Interleave</span><span>Execution schedules</span></div>
    {['A', 'B'].map((thread, row) => <div className="thread" key={thread}><span>Thread {thread}</span><div className="thread-track">{[0, 1, 2, 3, 4].map(column => <span key={column} className={(column + row) % 2 === 0 ? 'node filled' : 'node'} />)}</div></div>)}
    <div className="schedule-caption"><span className="status-dot" />Explore every possibility.</div>
  </div>;
}

/** Emphasize one exact phrase, keeping the surrounding prose readable. */
function Highlight({ text, phrase }) {
  const start = text.indexOf(phrase);
  if (start === -1) return text;
  return <>{text.slice(0, start)}<strong>{phrase}</strong>{text.slice(start + phrase.length)}</>;
}

/** One role at a time, with linked tabs, roving focus and full existing role descriptions. */
function ExperienceBrowser({ reduced }) {
  const [selected, setSelected] = useState(0);
  const [compact, setCompact] = useState(() => matchMedia('(max-width:900px)').matches);
  const prefix = useId();
  const tabs = useRef([]);
  const experience = experiences[selected];
  useEffect(() => {
    const media = matchMedia('(max-width:900px)');
    const update = () => setCompact(media.matches);
    media.addEventListener('change', update);
    update();
    return () => media.removeEventListener('change', update);
  }, []);

  function onKeyDown(event, index) {
    const previous = compact ? 'ArrowLeft' : 'ArrowUp';
    const next = compact ? 'ArrowRight' : 'ArrowDown';
    let target;
    if (event.key === previous) target = (index + experiences.length - 1) % experiences.length;
    else if (event.key === next) target = (index + 1) % experiences.length;
    else if (event.key === 'Home') target = 0;
    else if (event.key === 'End') target = experiences.length - 1;
    else return;
    event.preventDefault();
    event.stopPropagation();
    setSelected(target);
    tabs.current[target]?.focus();
    if (compact) tabs.current[target]?.scrollIntoView({ block: 'nearest', inline: 'nearest', behavior: 'instant' });
  }

  return <div className="experience-browser" data-reveal>
    <div className="experience-tabs" role="tablist" aria-label="Experience roles" aria-orientation={compact ? 'horizontal' : 'vertical'}>
      {experiences.map((role, index) => <button key={role.id} ref={node => { tabs.current[index] = node; }} type="button" role="tab" id={`${prefix}-tab-${role.id}`} aria-label={`${role.company}, ${role.title}, ${role.date}`} aria-selected={selected === index} aria-controls={`${prefix}-panel`} tabIndex={selected === index ? 0 : -1} onClick={() => setSelected(index)} onKeyDown={event => onKeyDown(event, index)}>
        <span className="experience-tab-top">{role.company}</span><span className="experience-tab-title">{role.selector ?? role.title}</span>
      </button>)}
    </div>
    <motion.article className="experience-panel" role="tabpanel" key={`${experience.id}-${reduced}`} id={`${prefix}-panel`} aria-labelledby={`${prefix}-tab-${experience.id}`} tabIndex={0} initial={reduced ? false : { opacity: 0, y: 4 }} animate={{ opacity: 1, y: 0 }} transition={{ duration: reduced ? 0 : 1.4, ease: [0.4, 0, 0.2, 1] }}>
      <p className="eyebrow">{experience.company}</p><h3>{experience.title}</h3><p className="experience-date">{experience.date}</p><ul>{experience.points.map(point => <li key={point}><Highlight text={point} phrase={experience.highlight} /></li>)}</ul>
    </motion.article>
  </div>;
}

/** Once-only entrances attach after render; reduced motion reveals every item immediately. */
function useEntrances(reduced, variant) {
  useEffect(() => {
    const items = [...document.querySelectorAll('[data-reveal]')];
    if (reduced || !('IntersectionObserver' in window)) {
      items.forEach(item => item.classList.remove('reveal-pending'));
      return;
    }
    const observer = new IntersectionObserver(entries => entries.forEach(entry => {
      if (entry.isIntersecting) {
        entry.target.classList.remove('reveal-pending');
        observer.unobserve(entry.target);
      }
    }), { threshold: 0.08 });
    items.forEach(item => { item.classList.add('reveal-pending'); observer.observe(item); });
    return () => {
      observer.disconnect();
      items.forEach(item => item.classList.remove('reveal-pending'));
    };
  }, [reduced, variant]);
}

/** Prototype app: viewport-sized intro, semantic sections and a button-centered theme wipe. */
export default function App() {
  const [variant, setVariant] = useState(() => {
    const requested = new URLSearchParams(location.search).get('variant');
    return layouts.includes(requested) ? requested : 'B';
  });
  const [theme, setTheme] = useState(() => document.documentElement.dataset.theme === 'light' ? 'light' : 'dark');
  const [menuOpen, setMenuOpen] = useState(false);
  const [active, setActive] = useState('');
  const reduced = Boolean(useReducedMotion());
  const transition = useRef(null);
  const fallbackTimer = useRef(null);
  const menu = useRef(null);
  useEntrances(reduced, variant);
  useEffect(() => () => clearTimeout(fallbackTimer.current), []);

  useEffect(() => {
    let frame = 0;
    const update = () => {
      frame = 0;
      const header = document.querySelector('.header').getBoundingClientRect().bottom;
      const line = Math.max(0, header) + innerHeight * 0.25;
      let current = '';
      sections.forEach(([id]) => { if (document.getElementById(id).getBoundingClientRect().top <= line) current = id; });
      if (scrollY > 100 && scrollY + innerHeight >= document.documentElement.scrollHeight - 4) current = 'contact';
      setActive(current);
    };
    const queue = () => { if (!frame) frame = requestAnimationFrame(update); };
    window.addEventListener('scroll', queue, { passive: true });
    window.addEventListener('resize', queue);
    update();
    return () => { cancelAnimationFrame(frame); window.removeEventListener('scroll', queue); window.removeEventListener('resize', queue); };
  }, [variant]);

  useEffect(() => {
    const keydown = event => {
      if (event.key === 'Escape' && menuOpen) { setMenuOpen(false); menu.current?.focus(); }
    };
    document.addEventListener('keydown', keydown);
    return () => document.removeEventListener('keydown', keydown);
  }, [menuOpen]);

  function switchTheme(event) {
    if (transition.current) return;
    const next = theme === 'light' ? 'dark' : 'light';
    const update = () => {
      document.documentElement.dataset.theme = next;
      try { localStorage.setItem('portfolio-theme', next); } catch { /* Theme still works when storage is blocked. */ }
      document.querySelector('meta[name="theme-color"]').content = next === 'light' ? '#F7F8FA' : '#131A23';
      flushSync(() => setTheme(next));
    };
    if (reduced) { update(); return; }
    if (!document.startViewTransition) {
      clearTimeout(fallbackTimer.current);
      document.documentElement.classList.add('theme-fallback');
      update();
      fallbackTimer.current = setTimeout(() => document.documentElement.classList.remove('theme-fallback'), 1600);
      return;
    }
    const bounds = event.currentTarget.getBoundingClientRect();
    const x = bounds.left + bounds.width / 2;
    const y = bounds.top + bounds.height / 2;
    const radius = Math.ceil(Math.hypot(Math.max(x, innerWidth - x), Math.max(y, innerHeight - y)));
    const root = document.documentElement;
    root.style.setProperty('--wipe-x', `${x}px`);
    root.style.setProperty('--wipe-y', `${y}px`);
    root.style.setProperty('--wipe-radius', `${radius}px`);
    transition.current = document.startViewTransition(update);
    transition.current.finished.catch(() => {}).finally(() => { transition.current = null; });
  }

  function changeVariant(step) {
    if (transition.current) return;
    const next = layouts[(layouts.indexOf(variant) + step + layouts.length) % layouts.length];
    const url = new URL(location.href);
    url.searchParams.set('variant', next);
    url.hash = '';
    history.replaceState(null, '', url);
    setVariant(next);
    setMenuOpen(false);
    window.scrollTo({ top: 0, behavior: 'instant' });
  }

  useEffect(() => {
    const keydown = event => {
      if (event.target.closest('input,textarea,select,[contenteditable],[role="tablist"],[data-project-carousel]')) return;
      if (event.key === 'ArrowLeft' || event.key === 'ArrowRight') { event.preventDefault(); changeVariant(event.key === 'ArrowRight' ? 1 : -1); }
    };
    document.addEventListener('keydown', keydown);
    return () => document.removeEventListener('keydown', keydown);
  }, [variant]);

  return <div className={`portfolio variant-${variant}`}>
    <div className="ambient-background" aria-hidden="true"><DotGrid dotSize={3} gap={10} proximity={170} tension={0.55} swell={1.2} glow={0.6} baseColor={theme === 'dark' ? '#465B70' : '#8B9CA9'} activeColor={theme === 'dark' ? '#9AC7D6' : '#326D83'} opacity={theme === 'dark' ? 0.35 : 0.23} mouseInteraction={!reduced} clickShock={!reduced} intro={!reduced} /></div>
    <a className="skip-link" href="#main">Skip to content</a>
    <header className="header"><div className="header-inner">
      <a href="#main" className="brand" aria-label="Samuel Hernandez Balderas, back to top"><span className="brand-at">@</span><span>samhb</span></a>
      <button className="menu-toggle" ref={menu} aria-expanded={menuOpen} aria-controls="navigation" onClick={() => setMenuOpen(!menuOpen)}>Menu</button>
      <nav id="navigation" className={menuOpen ? 'nav open' : 'nav'} aria-label="Main navigation">
        {sections.map(([id, label]) => <a key={id} href={`#${id}`} aria-current={active === id ? 'location' : undefined} onClick={() => setMenuOpen(false)}>{label}</a>)}
      </nav>
      <div className="header-controls"><a href="https://www.linkedin.com/in/samuelhb/" className="icon-button" target="_blank" rel="noopener noreferrer" aria-label="LinkedIn" title="LinkedIn"><Icon name="linkedin" /></a><a href="https://github.com/SamuelIVX" className="icon-button" target="_blank" rel="noopener noreferrer" aria-label="GitHub" title="GitHub"><Icon name="github" /></a><button className="icon-button theme-toggle" onClick={switchTheme} aria-label={`Switch to ${theme === 'light' ? 'dark' : 'light'} theme`} title="Switch theme"><Icon name={theme === 'light' ? 'moon' : 'sun'} /></button></div>
    </div></header>
    <main id="main" tabIndex="-1">
      <section className="hero" aria-label="Introduction">
        <motion.div className="hero-inner" key={`intro-${variant}-${reduced}`} initial={reduced ? false : { opacity: 0.2, y: 12, filter: 'blur(3px)' }} animate={{ opacity: 1, y: 0, filter: 'blur(0px)' }} transition={{ duration: reduced ? 0 : 2.6, ease: [0.22, 1, 0.36, 1] }}>
          <div className="hero-identity"><p className="greeting">Hello World, I'm...</p>
            <h1 className="hero-name" aria-label="Samuel Hernandez Balderas."><span aria-hidden="true">Samuel</span><span aria-hidden="true">Hernandez</span><span aria-hidden="true">Balderas.</span></h1>
            <div className="hero-actions"><a className="primary-button" href="#projects">Explore my work<Icon name="down" /></a><External href="/assets/resume.pdf">Resume</External></div>
          </div>
          <div className="hero-aside">
            <p className="profession">Software engineer <span>&amp; web developer.</span></p>
            <p className="hero-story">I build web applications and tools for understanding complex systems. Three summers in <strong>AWS Billing</strong> shaped my focus on performance, reliability, and <strong>end-to-end ownership</strong>.</p>
          </div>
        </motion.div>
      </section>

      <section className="section about" id="about"><div className="section-heading" data-reveal><p className="eyebrow">Beyond the Resume</p><h2>A little about me.</h2></div><div className="about-body" data-reveal><p className="lead">I enjoy building useful software and understanding what makes it work.</p><p>I'm a <strong>computer science senior</strong> at the College of Staten Island, with a minor in mathematics. Away from the keyboard, I'm usually at the gym, tinkering with PCs, reading manga, or adding to my figurine and comic collection.</p><div className="skills">{[['Languages', 'Java, TypeScript, Python, C++'], ['Applications', 'React, Next.js, Node.js, Tailwind'], ['Data & infrastructure', 'AWS, PostgreSQL, Supabase, Vercel'], ['Tools', 'Git, Maven']].map(([title, text]) => <div key={title}><h3>{title}</h3><p>{text}</p></div>)}</div></div></section>

      <section className="section projects" id="projects"><div className="section-heading" data-reveal><p className="eyebrow">Projects</p><h2>A few things I've built.</h2></div><ProjectCarousel /></section>

      <section className="section experience" id="work"><div className="section-heading" data-reveal><p className="eyebrow">Experience</p><h2>Built in the real world.</h2></div><ExperienceBrowser reduced={reduced} /></section>

      <section className="section honors" id="honors"><div className="section-heading" data-reveal><p className="eyebrow">Recognition</p><h2>Honors &amp; scholarships.</h2></div><div className="honors-grid">{honors.map(award => <article key={award.title} className={`honor-card${award.featured ? ' honor-featured' : ''}`} data-reveal><p className="honor-meta">{award.issuer}<span>{award.date}</span></p><h3>{award.title}</h3><p className="honor-amount">{award.amount}</p><p className="honor-distinction"><strong>{award.distinction}</strong></p><p className="honor-description"><Highlight text={award.description} phrase={award.highlight} /></p>{award.association && <p className="honor-association">{award.association}</p>}</article>)}</div></section>

      <section className="section contact" id="contact"><div className="contact-layout" data-reveal><div><p className="eyebrow">Get in touch</p><h2>Let's talk.</h2></div><div className="contact-action"><p>Have a role, a project, or a good question in mind?<br />I'd be glad to hear from you.</p><a className="email" href="mailto:samuel05.hb@gmail.com">samuel05.hb@gmail.com<Icon name="arrow" /></a></div></div></section>
    </main>
    <footer className="footer"><span>© {new Date().getFullYear()} Samuel Hernandez Balderas • All rights reserved.</span><a href="#main">Back to top<Icon name="down" /></a></footer>
    {import.meta.env.DEV ? <div className="prototype-switcher" aria-label="Prototype layout switcher"><button onClick={() => changeVariant(-1)} aria-label="Previous layout">←</button><span><small>Layout study</small>{variant} / {layoutNames[variant]}</span><button onClick={() => changeVariant(1)} aria-label="Next layout">→</button></div> : null}
  </div>;
}
